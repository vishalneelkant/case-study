package com.tokenwithoutllm.controller;

import com.tokenwithoutllm.model.Output;
import com.tokenwithoutllm.model.Prompt;
import com.tokenwithoutllm.service.TokenCounterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
public class TokenCalculatorController {

    @Autowired
    private TokenCounterService tokenCalculatorService;

    @PostMapping("/calculateToken")
    public ResponseEntity<Output> calculateToken(@RequestBody Prompt prompt){
        System.out.println("Token calculation request received : " + prompt);
        Output output = new Output();
        output.setToken(tokenCalculatorService.calculateToken(prompt.getPrompt()));
        return ResponseEntity.ok(output);
    }
}
