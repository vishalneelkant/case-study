package com.tokenwithoutllm.model;

public class Prompt {

    private String prompt;

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt;
    }


    @Override
    public String toString() {
        return "Prompt{" +
                "prompt='" + prompt + '\'' +
                '}';
    }
}
