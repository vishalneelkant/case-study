package com.tokenwithoutllm.service;

import ch.qos.logback.core.util.StringUtil;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.stream.Collectors;

@Service
public class TokenCounterService {

    public Integer calculateToken(String input){
        if (!StringUtils.hasLength(input)) {
            return 0;
        }
        String inputWithLeadingSpace = input.replace(" ", "");
        int tokenCount = inputWithLeadingSpace.length() / 4;
        if (inputWithLeadingSpace.length() % 4 != 0) {
            tokenCount += 1;
        }

        return tokenCount;
        //return Math.toIntExact(Arrays.stream(input.trim().split("\\s+")).collect(Collectors.toSet()).stream().count());

    }
}
