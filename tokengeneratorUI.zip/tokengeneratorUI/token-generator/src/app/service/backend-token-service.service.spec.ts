import { TestBed } from '@angular/core/testing';

import { BackendTokenServiceService } from './backend-token-service.service';

describe('BackendTokenServiceService', () => {
  let service: BackendTokenServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BackendTokenServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
