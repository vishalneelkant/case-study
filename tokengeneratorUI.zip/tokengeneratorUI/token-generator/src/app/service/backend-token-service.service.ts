import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Prompt } from 'src/assets/prompt';
import { InputData } from '../token-calculator/input-data.model';

@Injectable({
  providedIn: 'root'
})
export class BackendTokenServiceService {

  
  private apiUrl = 'http://localhost:8080/calculateToken';  
  private llmUrl = "http://localhost:8081/calculateToken"

  constructor(private http: HttpClient) {}

  calculateTokens(prompt: InputData): Observable<{ token: number }> {
    //const promptJson = JSON.stringify(prompt); 
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    console.log("promptJson: " + prompt);
    return this.http.post<{ token: number }>(this.apiUrl, prompt , {headers});
    
  }

  calculateTokens2(prompt: InputData): Observable<{ token: number }> {
    //const promptJson = JSON.stringify(prompt); 
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    console.log("promptJson: " + prompt);
    return this.http.post<{ token: number }>(this.llmUrl, prompt , {headers});
    
  }
}
