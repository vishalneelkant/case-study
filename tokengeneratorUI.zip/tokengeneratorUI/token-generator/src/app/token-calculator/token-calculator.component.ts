import { Component } from '@angular/core';
import { BackendTokenServiceService } from '../service/backend-token-service.service';
import { Prompt } from 'src/assets/prompt';
import { InputData } from './input-data.model';

@Component({
  selector: 'app-token-calculator',
  templateUrl: './token-calculator.component.html',
  styleUrls: ['./token-calculator.component.scss']
})
export class TokenCalculatorComponent {
  inputText: string = '';  
  tokenCount: number | null = null;  // Token count to be displayed

  inputData : InputData = {
    prompt: "string"
  };

  constructor(private tokenCalculatorService: BackendTokenServiceService) {}

  onSubmit() {

    console.log("input: ", this.inputText);

    // const prompt: Prompt = {
    //   prompt: this.inputText
    // };

    this.inputData.prompt = this.inputText;
    
    this.tokenCalculatorService.calculateTokens(this.inputData)
      .subscribe(
        response => {
          this.tokenCount = response.token;  // Update the token count from the response
        },
        error => {
          console.error('Error occurred while calculating tokens:', error);  // Handle any errors
        }
      );
  }

}
