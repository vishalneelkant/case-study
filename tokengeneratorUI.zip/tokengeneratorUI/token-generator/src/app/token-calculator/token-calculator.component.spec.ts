import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TokenCalculatorComponent } from './token-calculator.component';

describe('TokenCalculatorComponent', () => {
  let component: TokenCalculatorComponent;
  let fixture: ComponentFixture<TokenCalculatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TokenCalculatorComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TokenCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
