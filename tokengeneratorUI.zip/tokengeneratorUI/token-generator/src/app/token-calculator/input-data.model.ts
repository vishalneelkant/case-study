export interface InputData {
    prompt: string;
  }