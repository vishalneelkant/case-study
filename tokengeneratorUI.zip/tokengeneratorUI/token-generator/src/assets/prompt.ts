export class Prompt {
    prompt: string;
  
    constructor(prompt: string) {
      this.prompt = prompt;
    }
  
  }